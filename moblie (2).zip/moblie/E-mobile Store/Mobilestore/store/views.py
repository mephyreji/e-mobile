from django.shortcuts import render
from django.views.generic import TemplateView
from django.shortcuts import render,redirect
from django.views.generic import View,CreateView
from django.http import HttpResponse
from .forms import *
from django.contrib import messages
from django.urls import reverse_lazy
from .models import SProduct
from django.utils.decorators import method_decorator
# Create your views here.
def signin_required(fun):
    def wrapper(req,*args,**kwargs):
        if req.user.is_authenticated:
            return fun(req,*args,**kwargs)
        else :
            return redirect("log")
    return wrapper
@method_decorator(signin_required,name="dispatch")


class StoreHome(TemplateView):
    template_name="shome.html"





@method_decorator(signin_required,name="dispatch")
class ViewProduct(View):
    def get(self,request,*args, **kwargs):
           res=SProduct.objects.filter(store=request.user)
           print(res)
           return render(request,"view.html",{"data":res})
       
@method_decorator(signin_required,name="dispatch")
class DeleteView(View):
    def get(self,req,*args,**kwargs):
        sid=kwargs.get("ssid")
        stu=SProduct.objects.get(id=sid)
        stu.delete()
        return redirect("viw")


class EditView (View):
    def get(self,req,*args,**kwargs):
        id=kwargs.get("sid")
        stu=SProduct.objects.get(id=id)
        f=ProductMForm(instance=stu)
        return render(req,"edit.html",{"form":f})
    def post(self,req,*args,**kwargs):
        id=kwargs.get("sid")
        stu=SProduct.objects.get(id=id)
        form_data=ProductMForm(data=req.POST,instance=stu,files=req.FILES)
        if form_data.is_valid():
           form_data.save()
           messages.success(req,"Student-Details Updated Successfully!!")
           return redirect("viw")
        else:
            messages.error(req,"Updation Failed...") 
            return render(req,"edit.html",{"form":form_data})

class AddProductMForm(CreateView):
    template_name="addproduct.html"
    form_class=ProductMForm
    success_url=reverse_lazy("viw")
    model=SProduct
    def form_valid(self, form):
        print(self.request.user)
        form.instance.store=self.request.user
        print(form.instance)
        self.object=form.save()
        return super().form_valid(form)

