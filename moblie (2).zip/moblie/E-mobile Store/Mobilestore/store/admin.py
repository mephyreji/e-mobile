from django.contrib import admin
from .models import SProduct
# Register your models here.

admin.site.register(SProduct)