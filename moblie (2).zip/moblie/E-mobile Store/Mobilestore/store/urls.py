from django.urls import path
from .views import*

urlpatterns=[
    path("storeh",StoreHome.as_view(),name="shome"),
    path('add/',AddProductMForm.as_view(),name="add"),
    path('view/',ViewProduct.as_view(),name="viw"),
    path('del/<int:ssid>',DeleteView.as_view(),name="del"),
    path('edit/<int:sid>',EditView.as_view(),name="edit"),

]