from django.db import models
from account.models import CustUser
# Create your models here.

class SProduct(models.Model):
    title=models.CharField(max_length=100)
    description=models.CharField(max_length=100)
    price=models.CharField(max_length=100)
    image=models.ImageField(upload_to="product_images",null=True)
    store=models.ForeignKey(CustUser,on_delete=models.CASCADE,null=True)
      